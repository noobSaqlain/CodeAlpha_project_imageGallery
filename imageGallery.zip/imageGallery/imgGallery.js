document.querySelectorAll('.img-container .imgClass').forEach(imgClass => {
    imgClass.onclick = () => {
        const popupContainer = document.querySelector('.clicked-img');
        const popupImage = document.querySelector('#pop-up');

        popupContainer.style.display = 'block';
        popupImage.src = imgClass.getAttribute('src');
    };
});

document.querySelector('.clicked-img span').onclick = () => {
    document.querySelector('.clicked-img').style.display = 'none';
};
